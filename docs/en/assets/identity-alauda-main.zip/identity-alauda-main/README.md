---
task_categories:
  - text-classification
  - text-generation
dataset_info:
  config_name: default
  features:
    - name: instruction
      dtype: string
    - name: input
      dtype: string
    - name: output
      dtype: string
    - name: system
      dtype: string
configs:
- config_name: default
  data_files:
  - split: train
    path: "identity_alauda.jsonl"
---

Alauda Identity dataset for instruction fine tunning.
